﻿using System;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace test_WebApi.Controllers
{
    [ApiController]
    [Route("")]
    public class Controller : ControllerBase
    {
        [HttpGet]
        [Route("/Hello")]
        public Object Get()
        {
            return Ok(JsonConvert.SerializeObject(new { message = "Hello, Okruzhko Dmitrii" }));
        }

        [HttpPost]
        [Route("/PostHello")]
        public Object Post()
        {
            return Ok(JsonConvert.SerializeObject(new { datetime = DateTime.Now, Message = "Hello!" }));
        }
    }
}
